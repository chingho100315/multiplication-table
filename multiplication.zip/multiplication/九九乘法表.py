import tkinter as tk
from tkinter import ttk
from tkinter.messagebox import showerror, showinfo, askyesno
from pickle import load, dump
from PIL import Image, ImageTk
from os.path import isfile
from os.path import join as found
from sys import exit as exits
from random import randint, choice
from datetime import datetime, timedelta

tkroot = tk.Tk()
tkroot.geometry("1000x800")
tkroot.title("Multiplication Table")
tkroot.configure(bg="#FFFFFF")
FolderName = "multiplication"
PickleFile = found(FolderName, "multiplication.pkl")
FileValue = None
ranks = None
ishint = False
iswrong = False

tkroot.rowconfigure(0, weight=1)
tkroot.columnconfigure(0, weight=1)

toplevel = tk.Toplevel(tkroot)
toplevel.resizable(0, 0)
toplevel.transient(tkroot)

try:
    with open(PickleFile, "rb") as file:
        FileValue = load(file)
except Exception as error:
    if not isfile(PickleFile):
        with open(PickleFile, "wb") as file:
            FileValue = {
                "point" : 0, 
                "wrong" : 0, 
                "hint" : 0, 
                "frequency" : 0, 
                "ishint" : False, 
                "topic" : [randint(1, 9), randint(1, 9)], 
                "set" : {
                    "backcolor" : (255, 255, 255), 
                    "forecolor" : (0, 0, 0), 
                    "window" : 1, 
                    "double" : None
                }
            }
            dump(FileValue, file)
    else:
        showerror(
            "catch the error", 
            f"Please try again. error : {error}"
        )

if not FileValue.get("ishint"):
    toplevel.withdraw()

tkroot.attributes("-fullscreen", FileValue.get("set").get("window"))
first, second = FileValue.get("topic")

# 保存數據
def SaveFile():
    global FileValue
    with open(PickleFile, "wb") as file:
        dump(FileValue, file)

# 無時無刻監察double point是否完結
def CheckDouble():
    global FileValue
    if FileValue.get("set").get("double") != None:
        if datetime.now() > FileValue.get("set").get("double"):
            FileValue["set"]["double"] = None
            SaveFile()
            showinfo("double point", "雙倍時間已到")
    tkroot.after(10, CheckDouble)

# rgb換16進
def SetRgb(color):
    HexaList = []
    for hexadecimal in FileValue.get("set").get(color):
        HexaList.append(f"{hexadecimal:02X}")
    return "#" + "".join(HexaList)

# 窗口居中
def WindowCenter(window, xs=0, ys=0):
    window.update_idletasks()

    WindowWidth = window.winfo_width()
    WindowHeight = window.winfo_height()
    ScreenWidth = window.winfo_screenwidth()
    ScreenHeight = window.winfo_screenheight()

    x = (ScreenWidth // 2 - WindowWidth) + xs
    y = (ScreenHeight // 2 - WindowHeight) + ys

    window.geometry(f"+{x}+{y}")

# point的更新
def points():
    ranking()
    return f"""point : {FileValue.get('point')}
wrong : {FileValue.get('wrong')}
hint : {FileValue.get('hint')}
frequency : {FileValue.get('frequency')}
ranking : {ranks}"""

# 取得答案並判斷是否對
def GetAnswer():
    global FileValue, first, second, ishint, iswrong
    if askyesno("submit", f"是否提交, {first}×{second}={int(answer.get())}?"):
        if first*second == int(answer.get()):
            if not(ishint):
                if FileValue["set"]["double"] == None:
                    FileValue["point"] += 1
                else:
                    FileValue["point"] += 2
            FileValue["frequency"] += 1
            FileValue["ishint"] = False
            toplevel.withdraw()
            ishint = False
            iswrong = False
            answer.set(1)
            first = randint(1, 9)
            second = randint(1, 9)
            FileValue["topic"] = [first, second]
            point.configure(text=points())
            mul.configure(text=f"{first}×{second}=?")
            SaveFile()
            showinfo("Answer correct", "真棒")
        else:
            iswrong = True
            FileValue["wrong"] += 1
            FileValue["frequency"] += 1
            point.configure(text=points())
            SaveFile()
            showinfo("Answer wrong", "錯誤")

# 不斷更新滑杆值
def RenewValue():
    AnswerValue.configure(text=int(answer.get()))
    tkroot.after(100, RenewValue)

# 退出
def funexit():
    if askyesno("exit", "是否退出"):
        exits()

# 提示窗口
def HintTable():
    global FileValue, ishint
    if not FileValue.get("ishint"):
        if askyesno("hint", "是否開启提示\n開启後不能加分"):
            if not ishint:
                FileValue["hint"] += 1
                ishint = True
            FileValue["ishint"] = True
            toplevel.deiconify()
            point.configure(text=points())
            SaveFile()
    else:
        showinfo("", "你已有提示")

# 隱藏窗口
def close():
    if not FileValue.get("ishint"):
        toplevel.withdraw()

# 加入提示
def topinit():
    for a in range(1, 10):
        table = []
        for b in range(1, 10):
            table.append(f"{a}×{b}={a*b}")
        tk.Label(toplevel, font=("", 8), text="   ".join(table)). grid(row=a, column=0, sticky="w")

# 段位
def ranking():
    global ranks

    rank = [
        "黑鐵", 
        "青銅", 
        "白銀", 
        "黃金", 
        "鉑金", 
        "鑽石", 
        "大師", 
        "宗師", 
        "王者"
    ]

    RankPoint = [
        0, 
        100, 
        300, 
        500, 
        800, 
        1000, 
        1500, 
        2000, 
        3000
    ]

    color = [
        "#333333", 
        "#cc9966", 
        "#cccccc", 
        "#ffd700", 
        "#e5e4e2", 
        "#00ffff", 
        "#9932cc", 
        "#ff4500", 
        "#ff0000"
    ]

    points = (FileValue.get("point") - FileValue.get("wrong"))

    for a in range(len(RankPoint)-1, -1, -1):
        if points >= RankPoint[a]:
            ranks = rank[a]
            point.config(fg=color[a])
            break
        else:
            ranks = rank[0]
            point.config(fg=color[0])

# Setting的東西
class set:
    # 改背景顏色
    def BackCommand(self):
        global FileValue

        SetWindow = tk.Toplevel(tkroot)
        SetWindow.title("background")
        SetWindow.configure(bg="#FFFFFF")
        SetWindow.resizable(False, False)
        SetWindow.grab_set()
        WindowCenter(SetWindow, xs=-100)

        def scale_rgb():
            r = scale_red.get()
            g = scale_green.get()
            b = scale_blue.get()

            rgb = f"#{r:02X}{g:02X}{b:02X}"
            FileValue["set"]["backcolor"] = (r, g, b)
            SaveFile()

            OtherFrame.configure(bg=rgb)
            frame.configure(bg=rgb)
            point.config(bg=rgb)
            mul.config(bg=rgb)
            AnswerValue.config(bg=rgb)

            label_16.config(text=rgb)

            SetWindow.after(10, scale_rgb)

        # 創造滑桿
        def scale_init(color="#000000"):
            return tk.Scale(
                SetWindow, 
                from_=0,  
                to=255, 
                orient=tk.HORIZONTAL, 
                resolution=1, 
                length=580, 
                width=35, 
                bg=color, 
                troughcolor=color, 
                activebackground=color
            )

        # 初始化組件
        scale_red = scale_init(color="#FF0000")
        scale_green = scale_init(color="#00FF00")
        scale_blue = scale_init(color="#0000FF")

        SetRgb = FileValue.get("set").get("backcolor")

        scale_red.set(SetRgb[0])
        scale_green.set(SetRgb[1])
        scale_blue.set(SetRgb[2])

        label_16 = tk.Label(SetWindow, bg="#FFFFFF")
        label_16.grid(row = 3)

        scales = [scale_red, scale_green, scale_blue]

        for colors in range(len(scales)):
            nowcolors = scales[colors]
            nowcolors.grid(row=colors)

        scale_rgb()

    # 改文字顏色
    def ForeCommand(self):
        global FileValue

        SetWindow = tk.Toplevel(tkroot)
        SetWindow.title("foreground")
        SetWindow.configure(bg="#FFFFFF")
        SetWindow.resizable(False, False)
        SetWindow.grab_set()
        WindowCenter(SetWindow, xs=-100)

        def scale_rgb():
            r = scale_red.get()
            g = scale_green.get()
            b = scale_blue.get()

            rgb = f"#{r:02X}{g:02X}{b:02X}"
            FileValue["set"]["forecolor"] = (r, g, b)
            SaveFile()

            mul.config(fg=rgb)
            AnswerValue.config(fg=rgb)

            label_16.config(text=rgb)

            SetWindow.after(10, scale_rgb)

        # 創造滑桿
        def scale_init(color="#000000"):
            return tk.Scale(
                SetWindow, 
                from_=0,  
                to=255, 
                orient=tk.HORIZONTAL, 
                resolution=1, 
                length=580, 
                width=35, 
                bg=color, 
                troughcolor=color, 
                activebackground=color
            )

        # 初始化組件
        scale_red = scale_init(color="#FF0000")
        scale_green = scale_init(color="#00FF00")
        scale_blue = scale_init(color="#0000FF")

        SetRgb = FileValue.get("set").get("forecolor")

        scale_red.set(SetRgb[0])
        scale_green.set(SetRgb[1])
        scale_blue.set(SetRgb[2])

        label_16 = tk.Label(SetWindow, bg="#FFFFFF")
        label_16.grid(row = 3)

        scales = [scale_red, scale_green, scale_blue]

        for colors in range(len(scales)):
            nowcolors = scales[colors]
            nowcolors.grid(row=colors)

        scale_rgb()

    # 改窗口
    def Window(self):
        if FileValue.get("window") == 0:
            switch = 1
        else:
            switch = 0

        tkroot.attributes("-fullscreen", switch)
        tkroot.geometry("1000x800")
        tkroot.update_idletasks()
        FileValue["window"] = switch
        SaveFile()

    # 分數雙倍
    def Double(self):
        if FileValue.get("set").get("double") == None:
            if askyesno("double point", "是否花費100point\n來換取12分鐘內有雙倍分數"):
                FileValue["set"]["double"] = datetime.now() + timedelta(minutes=12)
                FileValue["point"] -= 100
                point.config(text=points())
                SaveFile()
        else:
            showinfo("double point", "你已經有雙倍分數")

    # 貓咪測試題
    def CatQuiz(self):
        QuizWindow = tk.Toplevel(tkroot)
        QuizWindow.title("cat quiz")
        QuizWindow.configure(bg="#FFFFFF")
        QuizWindow.grab_set()
        QuizWindow.resizable(False, False)

        WindowCenter(QuizWindow, xs=-430, ys=-300)
        QuizWindow.rowconfigure(0, weight=1)
        QuizWindow.columnconfigure(0, weight=1)

        QuizWindow.transient(tkroot)
        topic = choice(["紙巾", "蘿蔔"])

        def correct(value):
            nonlocal topic
            if value == topic:
                showinfo("", "真棒")
                topic = choice(["紙巾", "蘿蔔"])
                paper.config(text=topic)
                PaperButton.config(text=f"這個是{topic}")
                RadishButton.config(text=f"這個是{topic}")
            else:
                showinfo("", topic)

        paper = tk.Label(
            QuizWindow, 
            bg="#FFFFFF", 
            text=topic
        )
        paper.grid(sticky="n", row=0, column=1)

        image1 = Image.open(found("multiplication", "紙巾.png"))
        image1.thumbnail((400, 400))
        photo1 = ImageTk.PhotoImage(image1)

        image2 = Image.open(found("multiplication", "蘿蔔.png"))
        image2.thumbnail((400, 400))
        photo2 = ImageTk.PhotoImage(image2)

        image3 = Image.open(found("multiplication", "紙巾蘿蔔貓.png"))
        image3.thumbnail((400, 400))
        photo3 = ImageTk.PhotoImage(image3)

        PhotoPaper = tk.Label(
            QuizWindow, 
            bg="#FFFFFF", 
            image=photo1
        )
        PhotoPaper.grid(row=1, column=0)

        PhotoRadish = tk.Label(
            QuizWindow, 
            bg="#FFFFFF", 
            image=photo2
        )
        PhotoRadish.grid(row=1, column=2)

        PhotoCat = tk.Label(
            QuizWindow, 
            bg="#FFFFFF", 
            image=photo3
        )
        PhotoCat.grid(row=3, column=1)

        PhotoPaper.photo = photo1
        PhotoRadish.photo = photo2
        PhotoCat.photo = photo3

        PaperButton = ttk.Button(
            QuizWindow, 
            text=f"這個是{topic}", 
            command=lambda: correct("紙巾"), 
            style="paper.TButton"
        )
        PaperButton.grid(row=2, column=0)

        RadishButton = ttk.Button(
            QuizWindow, 
            text=f"這個是{topic}", 
            command=lambda: correct("蘿蔔"), 
            style="radish.TButton"
        )
        RadishButton.grid(row=2, column=2)

Set = set()

# 改顏色
style = ttk.Style()
style.theme_use("clam")

style.configure(
    "submit.TButton", 
    background="#FF0000", 
    foreground="#FF6400"
)

style.configure(
    "answer.Horizontal.TScale", 
    background="#FFC080", 
    troughcolor="#FFFF00"
)

style.configure(
    "exit.TButton", 
    background="#FFFF00", 
    foreground="#000000"
)

style.configure(
    "hint.TButton", 
    background="#FFC000", 
    foreground="#FFFFFF"
)

style.configure(
    "set.TMenubutton", 
    background="#0000FF", 
    foreground="#FFFFFF"
)

style.configure(
    "paper.TButton", 
    background="#0000FF", 
    foreground="#FFFFFF"
)

style.configure(
    "radish.TButton", 
    background="#00FF00", 
    foreground="#FF0000"
)

style.map(
    "submit.TButton", 
    background=[
        ("active", "#C80000")
    ], 
    foreground=[
        ("active", "#FF6400")
    ]
)

style.map(
    "answer.Horizontal.TScale", 
    background=[
        ("active", "#FFA080")
    ], 
    troughcolor=[
        ("active", "#FFC800")
    ]
)

style.map(
    "exit.TButton", 
    background=[
        ("active", "#C8C800")
    ]
)

style.map(
    "hint.TButton", 
    background=[
        ("active", "#FFA000")
    ], 
    foreground=[
        ("active", "#FFFFFF")
    ]
)

style.map(
    "set.TMenubutton", 
    background=[
        ("active", "#FF0000")
    ], 
    foreground=[
        ("active", "#000000")
    ]
)

style.map(
    "paper.TButton", 
    background=[
        ("active", "#00FFFF")
    ], 
    foreground=[
        ("active", "#FFFFFF")
    ]
)

style.map(
    "radish.TButton", 
    background=[
        ("active", "#FF0000")
    ], 
    foreground=[
        ("active", "#00FF00")
    ]
)

# 初始化組件
OtherFrame = tk.Frame(tkroot, bg="#FFFFFF")
OtherFrame.grid(row=0, column=0, sticky="nsew")
OtherFrame.rowconfigure(0, weight=1)
OtherFrame.columnconfigure(0, weight=1)

frame = tk.Frame(tkroot, bg="#FFFFFF")
frame.grid(row=0, column=0)

OtherFrame.config(bg=SetRgb("backcolor"))
frame.config(bg=SetRgb("backcolor"))

Setting = ttk.Menubutton(
    OtherFrame, 
    text="setting", 
    style="set.TMenubutton"
)
Setting.grid(row=0, column=1, sticky="n")

SetMenu = tk.Menu(
    Setting, 
    background="#0080FF", 
    foreground="#80FF00", 
    activebackground="#80FF00", 
    activeforeground="#0080FF", 
)
Setting["menu"] = SetMenu

MenuLabel = [
    "background", 
    "foreground", 
    "window", 
    "double", 
    "cat quiz"
]

MenuCommand = [
    Set.BackCommand, 
    Set.ForeCommand, 
    Set.Window, 
    Set.Double, 
    Set.CatQuiz
]

for ml, mc in zip(MenuLabel, MenuCommand):
    SetMenu.add_command(label=ml, command=mc)

mul = tk.Label(
    frame, 
    text=f"{first}×{second}=?", 
    bg=SetRgb("backcolor"), 
    fg=SetRgb("forecolor")
)
mul.grid(row=0, column=0)

answer = ttk.Scale(
    frame, 
    from_=1*1, 
    to=9*9, 
    orient="horizontal", 
    length=900, 
    style="answer.Horizontal.TScale"
)
answer.grid(row=2, column=0)
answer.set(1)

AnswerValue = tk.Label(
    frame, 
    bg=SetRgb("backcolor"), 
    fg=SetRgb("forecolor"), 
    text=int(answer.get())
)
AnswerValue.grid(row=1, column=0)

point = tk.Label(
    OtherFrame,  
    bg=SetRgb("backcolor")
)
point.grid(row=0, column=0, sticky="nw")

getanswer = ttk.Button(
    OtherFrame, 
    text="submit", 
    style="submit.TButton", 
    command=GetAnswer
)
getanswer.grid(row=1, column=0, sticky="w")

quits = ttk.Button(
    OtherFrame, 
    text="exit", 
    command=funexit, 
    style="exit.TButton"
)
quits.grid(row=1, column=2, sticky="s")

hint = ttk.Button(
    OtherFrame, 
    text="hint", 
    command=HintTable, 
    style="hint.TButton"
)
hint.grid(row=0, column=2, sticky="n")

CheckDouble()
ranking()
point.config(text=points())
toplevel.protocol("WM_DELETE_WINDOW", close)
topinit()
RenewValue()
tkroot.mainloop()